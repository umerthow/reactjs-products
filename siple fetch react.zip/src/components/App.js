import React, { Component } from 'react';

import '../App.css';



class App extends Component {



  componentDidMount(){
    this.getProducts()
  }


  getProducts = _ => {
    fetch('http://localhost:5000/products')
      .then(response => response.json())
      .then(response => this.setState({products : response.data}))
      .then(({ data }) => {
        console.log(data);
      })
      .catch(err => console.log(err))
  }

  addProduct = _ => {
    const { product } = this.state;
    
    fetch(`http://localhost:5000/product/add?name=${product.name}&price=${product.price}`)
   // .then(response => response.json())
    .then(this.getProducts)
    .catch(err => console.log(err))
  }

  state = {
    products : [],
    product : {
      name: 'test',
      price: 0
    }
  }

   renderProduct = ({ id, name }) => <div key={id}>{name}</div>;

  render() {
    const { products, product } = this.state;
    return (
      <div className="App">
        { products.map(this.renderProduct)}
      
          <div>
            product name : <input value={product.name} 
            onChange={e => this.setState({ product: {...product, name:e.target.value }})} />
            <br/>
           price :  <input type="number" value={product.price} 
           onChange={e => this.setState({ product: {...product, price:e.target.value }})} />
          
          <button onClick={this.addProduct}>Add </button>
          </div>
      </div>

    )
  }

}

export default App;
